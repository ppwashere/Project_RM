# SkinClassify > 2023-03-18 10:36pm
https://universe.roboflow.com/khon-kaen-university-zepoo/skinclassify

Provided by a Roboflow user
License: CC BY 4.0

